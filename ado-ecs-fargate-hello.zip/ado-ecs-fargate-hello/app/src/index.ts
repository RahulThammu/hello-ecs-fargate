import express from 'express';

const app = express();
const port = process.env.PORT || 3000;

app.get('/', (_req, res) => {
  res.type('text/plain').send('Hello, ECS Fargate from TypeScript!');
});

app.get('/health', (_req, res) => {
  res.status(200).type('text/plain').send('ok');
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
