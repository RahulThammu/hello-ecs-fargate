# Hello World to ECS Fargate via Azure DevOps + Terraform

This sample shows how to:
1. Build a **TypeScript** "Hello World" container.
2. Push it to **Amazon ECR**.
3. Deploy to **ECS Fargate** behind an **ALB**.
4. Orchestrate everything with an **Azure DevOps YAML pipeline** (no Classic).

## Prereqs
- AWS account with an IAM user that has permissions for ECR, ECS, IAM (role creation), ELB, CloudWatch Logs, and VPC. For quick demos, `AdministratorAccess` works (not for prod).
- Azure DevOps project with a repo.
- Free Microsoft-hosted agents are fine.
- In ADO > Pipelines > Library or pipeline variables, add secrets:
  - `AWS_ACCESS_KEY_ID`
  - `AWS_SECRET_ACCESS_KEY`
  - `AWS_ACCOUNT_ID`
  - Optionally adjust `AWS_REGION` (defaults to `us-east-1`).
  - `ECR_REPO` (defaults to `hello-app`).
  - `APP_NAME` (defaults to `hello-app`).

## Repo layout
```text
.
├─ app/                # TypeScript app
│  ├─ src/index.ts
│  ├─ package.json
│  └─ tsconfig.json
├─ infra/              # Terraform (ECR + ECS Fargate + ALB using default VPC)
│  ├─ versions.tf
│  ├─ providers.tf
│  ├─ variables.tf
│  ├─ main.tf
│  └─ outputs.tf
├─ Dockerfile          # multi-stage build
├─ .dockerignore
└─ azure-pipelines.yml # YAML pipeline
```

## One-time setup
1. Create a new ADO repo. Upload this project.
2. Create a Pipeline from `azure-pipelines.yml`.
3. Add pipeline variables/secrets as listed above.
4. (Optional) If your account has no default VPC/subnets, switch `main.tf` to create a VPC.

## What the pipeline does
1. **Infra_ECR**: `terraform apply -target=aws_ecr_repository.app` to ensure the ECR repo exists.
2. **Build_and_Push**: logs in to ECR, builds the Docker image, pushes both `:BuildId` and `:latest` tags.
3. **Infra_All**: full `terraform apply` with `-var image_tag=$(Build.BuildId)` so ECS runs the exact image that was built.

## After deploy
- Terraform outputs the ALB DNS. Visit `http://<alb_dns>`. You should see:
  ```
  Hello, ECS Fargate from TypeScript!
  ```

## Destroy
```bash
cd infra
terraform destroy
```

## Notes
- For a private service, use private subnets + NAT and drop `assign_public_ip`. For simplicity this sample uses public default subnets.
- To change the app port, update `container_port` variable and app `EXPOSE`/code as needed.
